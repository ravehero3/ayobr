// Re-export the Pairs component from PairContainer.jsx
export { default } from './PairContainer';